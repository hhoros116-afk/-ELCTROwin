élctrowin — SEO / Google setup

1. Put the site online on the real domain https://elctrowin.com/ (or change the domain in index.html, robots.txt and sitemap.xml).
2. Keep robots.txt and sitemap.xml at the website root.
3. Verify the domain in Google Search Console.
4. Submit https://elctrowin.com/sitemap.xml in Search Console.
5. Use URL Inspection to request indexing for the homepage.
6. For real product SEO, give each product its own public URL/page and put Product structured data in the initial HTML.

Important: the current demo stores products in the browser's localStorage. That is fine for a prototype, but it is not a production e-commerce backend and Google cannot reliably discover products that exist only in localStorage.
